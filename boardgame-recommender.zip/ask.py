"""
Ask for recommendations from the terminal:

    python ask.py

Type a request in any language and press Enter. 
"""

import logging

from app import llm
from app.recommender import recommend

logging.basicConfig(level=logging.ERROR)  # keep the terminal clean

print(f"Board game recommender ({'Gemini on' if llm.is_enabled() else 'no API key, basic mode'})")
print("Type your request in any language. Press Enter on an empty line to quit.\n")

while True:
    try:
        text = input("You: ").strip()
    except (KeyboardInterrupt, EOFError):
        break
    if not text:
        break

    result = recommend(text)
    print(f"\n  {result['game'] or 'No recommendation'}")
    print(f"  {result['reason']}")
    if llm.is_enabled() and llm.last_error:
        print(f"  (basic mode: {llm.last_error})")
    print()
