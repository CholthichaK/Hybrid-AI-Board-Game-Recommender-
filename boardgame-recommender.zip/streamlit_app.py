"""
The page where a user types their request.

    python -m streamlit run streamlit_app.py

It calls recommend() directly, so the FastAPI server doesn't need to be running.
"""

import streamlit as st

from app import llm
from app.recommender import GAMES, recommend

st.set_page_config(page_title="Board Game Recommender", page_icon="🎲")

# --- sidebar: API key -------------------------------------------------------
with st.sidebar:
    st.header("Settings")
    key = st.text_input(
        "Gemini API key", type="password", value=llm.API_KEY,
        help="Free from aistudio.google.com. Used only for this session, never saved.")
    llm.set_api_key(key)

    if llm.is_enabled():
        st.success(f"Gemini on ({llm.MODEL})")
    else:
        st.warning("No API key, so it runs in basic mode: keyword matching, "
                   "Thai and English replies only.")
    st.caption(f"{len(GAMES)} games in the catalog.")

# --- main page ----------------------------------------------------------------
st.title("What should we play tonight?")
st.write("Describe who's playing, how much time you have, or a game you already like. "
         "Write in any language and you'll get one game with the reason.")

with st.form("ask"):
    text = st.text_area("Your request", height=100,
                        placeholder="e.g. A family game for 4 that isn't too complicated")
    submitted = st.form_submit_button("Find a game", type="primary")

if submitted:
    if not text.strip():
        st.warning("Type a request first.")
    else:
        with st.spinner("Thinking..."):
            result = recommend(text.strip())

        if result["game"]:
            st.subheader(result["game"])
            st.write(result["reason"])
            # Show the dataset row, so it's clear the pick comes from the data.
            with st.expander("See this game's data"):
                row = GAMES[GAMES["name"] == result["game"]].iloc[0]
                st.json({k: (list(v) if k == "tags" else v.item() if hasattr(v, "item") else v)
                         for k, v in row.items()})
        else:
            st.info(result["reason"])

        if llm.is_enabled() and llm.last_error:
            st.caption(f"Answered in basic mode: {llm.last_error}")
