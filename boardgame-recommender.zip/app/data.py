"""
The game catalog.

The numbers come from the dataset in the assignment brief. I added one column
myself, `tags`, because the original columns can't answer questions like
"something similar to Splendor": two games can have the same player count and
playtime and still feel nothing alike. Tags describe how a game plays.

To swap in a bigger dataset (e.g. the BoardGameGeek dump on Kaggle), replace
load_games() and keep the same column names. Nothing else needs to change.
"""

import pandas as pd

# Closed list so the LLM can only pick tags that actually exist in the data.
TAG_VOCAB = [
    "engine building", "set collection", "card drafting", "tile placement",
    "trading", "negotiation", "route building", "area control",
    "cooperative", "campaign", "hand management", "resource management",
    "pattern building", "great for two", "gateway", "party size",
]

# These describe who a game suits, not how it plays, so similarity scoring
# ignores them. Otherwise "similar to Splendor" would match any game that is
# also beginner-friendly, which isn't what people mean.
AUDIENCE_TAGS = {"great for two", "gateway", "party size"}

CATEGORIES = ["Strategy", "Family", "Cooperative", "Abstract"]

_RAW = {
    "game_id": ["G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10"],
    "name": ["Catan", "Ticket to Ride", "Pandemic", "Carcassonne", "Gloomhaven",
             "Azul", "Wingspan", "Terraforming Mars", "Splendor", "7 Wonders"],
    "category": ["Strategy", "Family", "Cooperative", "Family", "Strategy",
                 "Abstract", "Strategy", "Strategy", "Family", "Strategy"],
    "min_players": [3, 2, 2, 2, 1, 2, 1, 1, 2, 3],
    "max_players": [4, 5, 4, 5, 4, 4, 5, 5, 4, 7],
    "playing_time": [90, 60, 45, 45, 120, 45, 70, 120, 30, 30],
    "min_age": [10, 8, 8, 7, 14, 8, 10, 12, 10, 10],
    "complexity": [2.3, 1.8, 2.4, 1.9, 3.9, 1.8, 2.4, 3.2, 1.8, 2.3],
    "avg_rating": [7.1, 7.4, 7.6, 7.4, 8.7, 7.8, 8.1, 8.4, 7.4, 7.7],
    "year": [1995, 2004, 2008, 2000, 2017, 2017, 2019, 2016, 2014, 2010],
    "tags": [
        ["trading", "negotiation", "resource management"],                    # Catan
        ["route building", "set collection", "gateway"],                       # Ticket to Ride
        ["cooperative", "hand management"],                                    # Pandemic
        ["tile placement", "area control", "gateway", "great for two"],        # Carcassonne
        ["cooperative", "campaign", "hand management"],                        # Gloomhaven
        ["pattern building", "tile placement", "great for two"],               # Azul
        ["engine building", "card drafting", "set collection"],                # Wingspan
        ["engine building", "card drafting", "resource management"],           # Terraforming Mars
        ["engine building", "set collection", "great for two", "gateway"],     # Splendor
        ["card drafting", "set collection", "party size"],                     # 7 Wonders
    ],
}


def validate(df: pd.DataFrame) -> None:
    """Fail loudly at startup rather than giving weird recommendations later."""
    required = {"name", "category", "min_players", "max_players", "playing_time",
                "min_age", "complexity", "avg_rating", "year", "tags"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"dataset is missing columns: {sorted(missing)}")

    if df["name"].duplicated().any():
        raise ValueError("duplicate game names in dataset")
    if (df["min_players"] > df["max_players"]).any():
        raise ValueError("some game has min_players > max_players")
    if not df["complexity"].between(1, 5).all():
        raise ValueError("complexity should be on the 1-5 BGG scale")
    if (df["playing_time"] <= 0).any():
        raise ValueError("playing_time must be positive")

    unknown_tags = {t for tags in df["tags"] for t in tags} - set(TAG_VOCAB)
    if unknown_tags:
        raise ValueError(f"tags not in TAG_VOCAB: {sorted(unknown_tags)}")


def load_games() -> pd.DataFrame:
    df = pd.DataFrame(_RAW)
    validate(df)
    return df


def find_game(df: pd.DataFrame, name: str | None):
    """Case-insensitive lookup; also accepts partial names like 'terraforming'."""
    if not name:
        return None
    name = name.strip().lower()
    for _, row in df.iterrows():
        game = row["name"].lower()
        if game == name:
            return row
        # partial match only for longer strings, otherwise "a" matches everything
        if len(name) >= 4 and (name in game or game in name):
            return row
    return None
