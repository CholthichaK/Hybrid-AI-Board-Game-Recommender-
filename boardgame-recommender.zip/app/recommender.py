"""
Steps 2-4: filter, rank, explain.

Main rule of this design: the LLM never chooses the game. It only reads the
request (parser.py) and writes the final explanation. The choice itself is
plain Python over the dataset, so it can't recommend a game that doesn't
exist, and every pick can be traced back to a score.
"""

import json
import logging
import math
import re
from itertools import combinations

import pandas as pd

from . import llm
from .data import AUDIENCE_TAGS, find_game, load_games
from .parser import parse_intent
from .schemas import Intent

log = logging.getLogger(__name__)

GAMES = load_games()

# Rough target on the BGG 1-5 weight scale for each complexity word.
COMPLEXITY_TARGET = {"light": 1.7, "medium": 2.5, "heavy": 3.5}


# --- step 2: hard constraints ------------------------------------------------

def filter_games(df: pd.DataFrame, intent: Intent, exclude: str | None = None):
    """Drop games that physically can't work for the user.

    If nothing survives, loosen the constraints one at a time, least important
    first. Better to suggest a 150-minute game and say so than to return nothing.
    Returns (candidates, list of constraints we had to relax).
    """
    if exclude:
        df = df[df["name"] != exclude]

    rules = []  # (label, mask) in the order we'd give them up
    if intent.max_minutes:
        rules.append((f"under {intent.max_minutes} minutes",
                      df["playing_time"] <= intent.max_minutes))
    if intent.youngest_age:
        rules.append((f"suitable for age {intent.youngest_age}",
                      df["min_age"] <= intent.youngest_age))
    if intent.players:
        rules.append((f"{intent.players} players",
                      df["min_players"].le(intent.players) & df["max_players"].ge(intent.players)))

    if not rules:
        return df, []

    # Try dropping as few rules as possible: none, then one, then two...
    # combinations() keeps list order, so less important rules go first.
    for n_dropped in range(len(rules) + 1):
        for dropped in combinations(range(len(rules)), n_dropped):
            mask = pd.Series(True, index=df.index)
            for i, (_, m) in enumerate(rules):
                if i not in dropped:
                    mask &= m
            if mask.any():
                return df[mask], [rules[i][0] for i in dropped]
    return df, [label for label, _ in rules]  # unreachable: dropping all keeps everything


# --- step 3: soft ranking ----------------------------------------------------

def score_game(row, intent: Intent, ref=None) -> tuple[float, list[str]]:
    """Higher is better. Also returns short notes on why, which feed the explanation."""
    notes = []

    # Rating is a gentle baseline, mostly to break ties between similar games.
    score = (row["avg_rating"] - 7) * 0.5

    if row["category"] in intent.categories:
        score += 1.5
        notes.append(f"it is a {row['category'].lower()} game")

    wanted = list(intent.tags)
    if intent.players == 2 and "great for two" not in wanted:
        # Many games "support" 2 players but are much better with more.
        wanted.append("great for two")
    matched = [t for t in wanted if t in row["tags"]]
    if matched:
        score += 0.75 * len(matched)
        notes.append("it is " + ", ".join(matched))

    if intent.complexity:
        gap = abs(row["complexity"] - COMPLEXITY_TARGET[intent.complexity])
        score -= gap
        if gap <= 0.5:
            notes.append(f"its complexity ({row['complexity']}/5) fits a {intent.complexity} game")
    elif row["complexity"] > 2.5:
        # Nobody asked for heavy, and a heavy game is a bad surprise on game night.
        score -= (row["complexity"] - 2.5) * 0.3

    if intent.wants_new:
        # "New" is relative to what's in the catalog. Full bonus for the newest,
        # fading out over about three years.
        years_behind = GAMES["year"].max() - row["year"]
        score += max(0.0, 3 - years_behind)
        if years_behind == 0:
            notes.append(f"it came out in {row['year']}, the newest game in our catalog")

    if ref is not None:
        sim, shared = similarity(row, ref)
        score += sim
        if shared:
            notes.append(f"like {ref['name']}, it has " + ", ".join(shared))

    if intent.players and row["min_players"] <= intent.players <= row["max_players"]:
        notes.append(f"it works for {intent.players} players")
        if row["min_players"] < intent.players < row["max_players"]:
            # Not at the edge of the box's player range, which usually plays better.
            score += 0.2

    if intent.youngest_age and row["min_age"] <= intent.youngest_age:
        notes.append(f"it is suitable from age {row['min_age']}")

    if intent.max_minutes:
        over = row["playing_time"] - intent.max_minutes
        if over > 0:
            # Only happens when we had to relax the time limit: prefer the closest miss.
            score -= over / 30
        else:
            notes.append(f"it fits in {intent.max_minutes} minutes")

    return score, notes


def similarity(row, ref) -> tuple[float, list[str]]:
    """How much a game plays like the reference game."""
    a = set(row["tags"]) - AUDIENCE_TAGS
    b = set(ref["tags"]) - AUDIENCE_TAGS
    shared = sorted(a & b)
    jaccard = len(shared) / len(a | b) if a | b else 0.0

    # Similar weight and length matter too, but less than how the game plays.
    weight_sim = 1 - min(abs(row["complexity"] - ref["complexity"]) / 4, 1)
    time_sim = 1 - min(abs(math.log(row["playing_time"] / ref["playing_time"])), 1)

    return 3 * jaccard + 0.5 * weight_sim + 0.5 * time_sim, shared


def rank(candidates: pd.DataFrame, intent: Intent, ref=None) -> list[tuple]:
    results = []
    for _, row in candidates.iterrows():
        s, notes = score_game(row, intent, ref)
        results.append((s, row, notes))
    results.sort(key=lambda r: r[0], reverse=True)
    return results


# ---- step 4: explanation -----------------------------------------------------

# Asking the model to "reply in the user's language" isn't reliable: in testing,
# some answers came back in the wrong language. So the language is decided in
# code and named explicitly in the prompt.
SCRIPTS = [  # (unicode range, language)
    (r"[\u0E00-\u0E7F]", "Thai"),
    (r"[\u3040-\u30FF]", "Japanese"),   # hiragana/katakana
    (r"[\uAC00-\uD7AF]", "Korean"),
    (r"[\u4E00-\u9FFF]", "Chinese"),
    (r"[\u0400-\u04FF]", "Russian"),
    (r"[\u0600-\u06FF]", "Arabic"),
]


def reply_language(text: str, intent: Intent, source: str) -> str:
    """Script check first (certain), then the parser's guess for Latin-script
    languages like Spanish or French, then English."""
    for pattern, language in SCRIPTS:
        if re.search(pattern, text):
            return language
    if source == "llm" and intent.language:
        return intent.language
    return "English"


EXPLAIN_PROMPT = """You explain a board game recommendation to a user in 2-3 friendly sentences.
You MUST write the whole answer in {language}.
Use ONLY the facts given below. Do not describe the game's theme,
story or rules, because they are not in the facts. Do not mention other games, except one
the user compared it to. If wishes_we_could_not_meet has items, say so honestly;
if it is empty, don't mention it at all."""


def explain(row, intent: Intent, notes: list[str], relaxed: list[str],
            ref_missing: str | None, user_text: str, language: str) -> str:
    facts = {
        "user_message": user_text,
        "game": row["name"],
        "category": row["category"],
        "players": f"{row['min_players']}-{row['max_players']}",
        "playing_time_minutes": int(row["playing_time"]),
        "min_age": int(row["min_age"]),
        "complexity_out_of_5": float(row["complexity"]),
        "avg_rating_out_of_10": float(row["avg_rating"]),
        "year": int(row["year"]),
        "why_it_matches": notes,
        "wishes_we_could_not_meet": relaxed,
    }
    if ref_missing:
        facts["wishes_we_could_not_meet"] = relaxed + [
            f"'{ref_missing}' is not in our catalog, so this is the closest match we have"]

    text = llm.chat(EXPLAIN_PROMPT.format(language=language),
                    json.dumps(facts, ensure_ascii=False) + f"\n\nAnswer in {language}.",
                    temperature=0.4)
    return text or template_reason(row, language, notes, relaxed)


def template_reason(row, language: str, notes: list[str], relaxed: list[str]) -> str:
    """Plain fallback when the LLM is down. Thai or English only."""
    if language == "Thai":
        reason = (f"แนะนำ {row['name']} เล่นได้ {row['min_players']}-{row['max_players']} คน "
                  f"ใช้เวลาประมาณ {row['playing_time']} นาที ความยาก {row['complexity']}/5 "
                  f"และคะแนนเฉลี่ย {row['avg_rating']}/10")
        if relaxed:
            reason += " (ไม่พบเกมที่ตรงทุกเงื่อนไข จึงผ่อนเงื่อนไข: " + ", ".join(relaxed) + ")"
        return reason

    reason = (f"{row['name']} plays {row['min_players']}-{row['max_players']} people in about "
              f"{row['playing_time']} minutes, with complexity {row['complexity']}/5 "
              f"and an average rating of {row['avg_rating']}/10.")
    if notes:
        reason += " It's a good match because " + "; ".join(notes) + "."
    if relaxed:
        reason += " No game met every condition, so I loosened: " + ", ".join(relaxed) + "."
    return reason


OFF_TOPIC = ("I can only help with board game recommendations. "
             "Tell me who's playing, how long you have, or a game you like!")
OFF_TOPIC_TH = "ขออภัย ระบบนี้แนะนำได้เฉพาะบอร์ดเกม ลองบอกจำนวนผู้เล่น เวลาที่มี หรือเกมที่ชอบดูนะ"


def off_topic_reply(language: str) -> str:
    if language == "English":
        return OFF_TOPIC
    translated = llm.chat(f"Translate the user's text into {language}. Reply with the translation only.",
                          OFF_TOPIC)
    if translated:
        return translated
    return OFF_TOPIC_TH if language == "Thai" else OFF_TOPIC


# --- the function the assignment asks for ------------------------------------

def recommend(text: str) -> dict:
    """Free text in, one board game and a reason out."""
    llm.last_error = None
    intent, source = parse_intent(text)
    log.info("intent (%s): %s", source, intent.model_dump(exclude_defaults=True))

    language = reply_language(text, intent, source)

    if not intent.on_topic:
        return {"game": None, "reason": off_topic_reply(language)}

    ref = find_game(GAMES, intent.similar_to)
    ref_missing = intent.similar_to if intent.similar_to and ref is None else None

    candidates, relaxed = filter_games(GAMES, intent,
                                       exclude=ref["name"] if ref is not None else None)
    ranked = rank(candidates, intent, ref)
    score, best, notes = ranked[0]
    if not notes:
        notes = ["no specific preferences were given, so this is a highly rated, approachable pick"]
    log.info("picked %s (score %.2f), relaxed=%s", best["name"], score, relaxed)

    return {"game": best["name"],
            "reason": explain(best, intent, notes, relaxed, ref_missing, text, language)}
