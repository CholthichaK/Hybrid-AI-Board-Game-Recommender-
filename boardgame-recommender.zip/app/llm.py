"""
Thin wrapper around Gemini through its OpenAI-compatible endpoint.

The key comes from .env (LLM_API_KEY), or can be set at runtime with
set_api_key(), which the Streamlit page uses so reviewers can paste their own.

If there is no key, or a call fails, chat() returns None and the caller falls
back to the non-LLM path. The service never crashes because of the LLM.
"""

import logging
import os

from dotenv import load_dotenv

load_dotenv()
log = logging.getLogger(__name__)

BASE_URL = os.getenv("LLM_BASE_URL", "https://generativelanguage.googleapis.com/v1beta/openai/")
MODEL = os.getenv("LLM_MODEL", "gemini-2.5-flash")
API_KEY = os.getenv("LLM_API_KEY", "").strip()
TIMEOUT = float(os.getenv("LLM_TIMEOUT", "20"))

_client = None
# Set when a call fails, reset by recommend() at the start of each request.
# Shown in the UI so a rate limit isn't a mystery.
last_error: str | None = None


def set_api_key(key: str) -> None:
    global API_KEY, _client
    key = key.strip()
    if key != API_KEY:
        API_KEY = key
        _client = None  # rebuild the client with the new key


def is_enabled() -> bool:
    return bool(API_KEY) and os.getenv("LLM_DISABLED", "0") != "1"


def _get_client():
    global _client
    if _client is None:
        from openai import OpenAI
        # No automatic retries: on the free tier, retrying a rate-limited call
        # just burns more quota. We fall back straight away instead.
        _client = OpenAI(base_url=BASE_URL, api_key=API_KEY, timeout=TIMEOUT, max_retries=0)
    return _client


def _describe(e: Exception) -> str:
    """Turn API errors into something a person can act on."""
    status = getattr(e, "status_code", None)
    if status == 429:
        return "Gemini free quota reached. Wait a minute (or until tomorrow for the daily limit)."
    if status in (400, 401, 403):
        return "Gemini rejected the API key. Check that it was copied correctly."
    if status == 404:
        return f"Model '{MODEL}' not found. Check LLM_MODEL in .env."
    return str(e).splitlines()[0][:150]


def chat(system: str, user: str, temperature: float = 0.0) -> str | None:
    global last_error
    if not is_enabled():
        return None
    try:
        resp = _get_client().chat.completions.create(
            model=MODEL,
            temperature=temperature,
            messages=[{"role": "system", "content": system},
                      {"role": "user", "content": user}],
        )
        return (resp.choices[0].message.content or "").strip() or None
    except Exception as e:  # network, auth, rate limit... all lead to the fallback
        last_error = _describe(e)
        log.warning("LLM call failed, using fallback: %s", last_error)
        return None
