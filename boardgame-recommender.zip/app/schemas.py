from typing import Literal

from pydantic import BaseModel, Field


class Intent(BaseModel):
    """What we understood from the user's message. Every field is optional
    because most people only mention one or two things."""

    players: int | None = Field(None, ge=1, le=20)
    max_minutes: int | None = Field(None, ge=5)
    youngest_age: int | None = Field(None, ge=2, le=99)
    complexity: Literal["light", "medium", "heavy"] | None = None
    categories: list[str] = []
    tags: list[str] = []
    similar_to: str | None = None
    wants_new: bool = False
    on_topic: bool = True        # False for things like "what's the weather?"
    language: str = "English"    # the language we should answer in


class RecommendRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=1000,
                       examples=["I'm looking for a board game to play with my partner"])


class RecommendResponse(BaseModel):
    game: str | None
    reason: str
