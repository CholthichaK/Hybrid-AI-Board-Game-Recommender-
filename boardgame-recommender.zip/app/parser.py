"""
Step 1: turn free text (any language) into an Intent.

The LLM does the understanding because it handles languages, slang and
implied meaning ("with my partner" -> 2 players). Its output is validated
with Pydantic, so a malformed answer can't sneak into the rest of the system.

If the LLM is unavailable, a keyword parser takes over. It only knows
English and Thai and misses subtle requests, but it keeps the service up.
"""

import json
import logging
import re

from pydantic import ValidationError

from . import llm
from .data import CATEGORIES, TAG_VOCAB, load_games
from .schemas import Intent

log = logging.getLogger(__name__)

SYSTEM_PROMPT = f"""You read board game requests written in any language and extract what the user wants.
Reply with JSON only, no markdown, using exactly these keys:

  players        int or null   - how many people will play ("with my partner" = 2, "solo" = 1)
  max_minutes    int or null   - longest acceptable play time in minutes
  youngest_age   int or null   - age of the youngest player, if mentioned
  complexity     "light" | "medium" | "heavy" | null   ("not too complicated" = light)
  categories     list, any of {CATEGORIES}
  tags           list, any of {TAG_VOCAB}
  similar_to     string or null - a game the user likes or wants something similar to
  wants_new      bool - true if they ask for new / recent / latest games
  on_topic       bool - false if the message is not about choosing a board game
  language       string - the language the user wrote in, in English (e.g. "Thai")

If the user names a game they like, also add the tags that describe how that game plays.
Only fill in what the user actually said or clearly implied. Use null or [] otherwise."""


def parse_intent(text: str) -> tuple[Intent, str]:
    """Returns (intent, source) where source is 'llm' or 'fallback'."""
    raw = llm.chat(SYSTEM_PROMPT, text)
    if raw:
        intent = _from_llm(raw)
        if intent is not None:
            return intent, "llm"
    return keyword_parse(text), "fallback"


def _from_llm(raw: str) -> Intent | None:
    # Models sometimes wrap JSON in ```json fences even when told not to.
    cleaned = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
    try:
        data = json.loads(cleaned)
        # Drop anything outside our vocab instead of failing the whole request.
        data["tags"] = [t for t in data.get("tags") or [] if t in TAG_VOCAB]
        data["categories"] = [c for c in data.get("categories") or [] if c in CATEGORIES]
        return Intent(**data)
    except (json.JSONDecodeError, ValidationError, TypeError) as e:
        log.warning("Could not use LLM output (%s): %r", e, raw[:200])
        return None


# --- keyword fallback --------------------------------------------------------

THAI_CHARS = re.compile(r"[\u0E00-\u0E7F]")


def keyword_parse(text: str) -> Intent:
    t = text.lower()
    intent = Intent(language="Thai" if THAI_CHARS.search(text) else "English")

    # players ("4 players", "four people", "สี่คน")
    words = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
             "สอง": 2, "สาม": 3, "สี่": 4, "ห้า": 5, "หก": 6}
    number = r"(\d+|" + "|".join(words) + r")"
    if m := re.search(number + r"\s*(?:players?|people|persons?|คน)", t):
        n = m.group(1)
        intent.players = int(n) if n.isdigit() else words[n]
    elif re.search(r"partner|couple|girlfriend|boyfriend|wife|husband|two of us|แฟน|สองคน", t):
        intent.players = 2
        intent.tags.append("great for two")
    elif re.search(r"\bsolo\b|by myself|alone|คนเดียว", t):
        intent.players = 1

    # time limit
    if m := re.search(r"(\d+(?:\.\d+)?)\s*(?:hours?|hrs?|ชั่วโมง|ชม)", t):
        intent.max_minutes = int(float(m.group(1)) * 60)
    elif m := re.search(r"(\d+)\s*(?:min(?:ute)?s?|นาที)", t):
        intent.max_minutes = int(m.group(1))

    if m := re.search(r"(\d+)\s*(?:years? old|y/?o|ขวบ|歳)", t):
        intent.youngest_age = int(m.group(1))

    # check "not too complicated" before "complicated"
    if re.search(r"(?:not|n'?t) (?:too |very |that )?(?:complicated|hard|complex|difficult)"
                 r"|simple|easy|beginner|ง่าย|ไม่ยาก", t):
        intent.complexity = "light"
    elif re.search(r"heavy|complex|complicated|deep|challenging|ยาก", t):
        intent.complexity = "heavy"

    for cat, pattern in {
        "Strategy": r"strateg|วางแผน|กลยุทธ์",
        "Family": r"family|kids|children|ครอบครัว|เด็ก",
        "Cooperative": r"co-?op|cooperative|together|teamwork|ร่วมมือ",
        "Abstract": r"abstract|puzzle",
    }.items():
        if re.search(pattern, t):
            intent.categories.append(cat)

    if re.search(r"\bnew\b|newest|newly|recent|latest|ใหม่", t):
        intent.wants_new = True

    # any known game name mentioned is almost always "something like X"
    for name in load_games()["name"]:
        if name.lower() in t:
            intent.similar_to = name
            break

    # Without an LLM we can't really judge intent. If nothing above matched and
    # the text doesn't even mention games or playing, assume it's off topic.
    has_signal = intent.model_dump(exclude_defaults=True).keys() - {"language"}
    on_topic_words = (r"game|play|like|similar|recommend|เกม|เล่น|เหมือน|คล้าย|แนะนำ"
                      r"|juego|jeu|spiel|ゲーム|游戏|遊戲|桌游")
    if not has_signal and not re.search(on_topic_words, t):
        intent.on_topic = False

    return intent
