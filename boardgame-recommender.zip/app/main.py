"""
HTTP layer. Kept thin on purpose: all the logic lives in recommender.py so it
can be used and tested without running a server.

Run:  uvicorn app.main:app --reload
Docs: http://localhost:8000/docs
"""

import logging

from fastapi import FastAPI

from . import llm
from .recommender import GAMES, recommend
from .schemas import RecommendRequest, RecommendResponse

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

app = FastAPI(title="Board Game Recommender", version="1.0")


@app.get("/health")
def health():
    return {"status": "ok", "games_loaded": len(GAMES), "llm_enabled": llm.is_enabled()}


@app.post("/recommend", response_model=RecommendResponse)
def recommend_endpoint(req: RecommendRequest):
    return recommend(req.query)
