# Board Game Recommender

Type what you're looking for in any language, get one board game and the reason.

```python
from app.recommender import recommend
recommend("A game to play with my partner")
```

## How it works

1. Gemini turns the request into fields (players, time, complexity, "similar to").
2. Python filters and ranks the 10 games from the brief.
3. Gemini explains the pick in the user's language, using only the dataset.

The LLM never picks the game itself. Without a key or when rate-limited, it falls back to keyword matching (Thai and English only).

added a `tags` column to the dataset so "similar to Splendor" works.

## Run

```bash
python -m pip install -r requirements.txt
python -m streamlit run streamlit_app.py
```

Add your own Gemini key in the sidebar, or in `.env`.

Other options: `python ask.py` (terminal), `python -m uvicorn app.main:app` (API), `python -m pytest` (tests).