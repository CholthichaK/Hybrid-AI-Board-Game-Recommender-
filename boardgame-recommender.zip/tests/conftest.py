import os

# Tests run offline and give the same result every time, so the LLM is off.
# The LLM path is tested separately with fake responses (see test_parser.py).
os.environ["LLM_DISABLED"] = "1"
