"""LLM path, tested with fake model responses so no API key is needed."""

import json

from app import llm, parser
from app.recommender import recommend


def fake_llm(response):
    return lambda system, user, temperature=0.0: response


def test_llm_json_is_used(monkeypatch):
    # Japanese: "a game for two that isn't too difficult"
    answer = json.dumps({"players": 2, "complexity": "light", "tags": ["great for two"],
                         "language": "Japanese"})
    monkeypatch.setattr(llm, "chat", fake_llm(answer))
    intent, source = parser.parse_intent("二人で遊べる、あまり難しくないゲーム")
    assert source == "llm"
    assert intent.players == 2 and intent.language == "Japanese"


def test_markdown_fences_are_stripped(monkeypatch):
    monkeypatch.setattr(llm, "chat", fake_llm('```json\n{"players": 4}\n```'))
    intent, source = parser.parse_intent("4 players")
    assert source == "llm" and intent.players == 4


def test_unknown_tags_are_dropped(monkeypatch):
    monkeypatch.setattr(llm, "chat", fake_llm('{"tags": ["engine building", "made-up tag"]}'))
    intent, _ = parser.parse_intent("x")
    assert intent.tags == ["engine building"]


def test_garbage_from_llm_falls_back(monkeypatch):
    monkeypatch.setattr(llm, "chat", fake_llm("Sure! Here are some games you might like..."))
    intent, source = parser.parse_intent("game for 3 players")
    assert source == "fallback" and intent.players == 3


def test_off_topic(monkeypatch):
    monkeypatch.setattr(llm, "chat", fake_llm('{"on_topic": false}'))
    assert recommend("what's the weather tomorrow?")["game"] is None
