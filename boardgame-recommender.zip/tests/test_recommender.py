"""
The five queries from the assignment brief, plus edge cases.
These double as regression tests: if a scoring change flips one of these
answers, I want to know about it.
"""

import pytest
from fastapi.testclient import TestClient

from app.data import load_games, validate
from app.main import app
from app.recommender import recommend, reply_language
from app.schemas import Intent


@pytest.mark.parametrize("query, expected", [
    ("I'm looking for a family game for 4 players that isn't too complicated.", "Ticket to Ride"),
    ("I want a strategy game that takes no more than 2 hours to play.", "Wingspan"),
    ("I'm looking for a board game to play with my partner.", "Azul"),
    ("What are some interesting newly released board games?", "Wingspan"),
    ("I like games similar to Splendor.", "Wingspan"),
])
def test_brief_examples(query, expected):
    assert recommend(query)["game"] == expected


def test_thai_query():
    result = recommend("อยากได้เกมเล่นกับแฟน ไม่ยากมาก")  # a not-too-hard game to play with my partner
    assert result["game"] == "Azul"
    assert "Azul" in result["reason"]


def test_unknown_game_is_still_on_topic():
    # Dixit isn't in the catalog, but this is clearly a board game request
    assert recommend("Something like Dixit please")["game"] is not None


def test_off_topic_without_llm():
    assert recommend("what's the weather in Bangkok?")["game"] is None


def test_never_recommends_the_game_you_compared_to():
    assert recommend("something like Catan")["game"] != "Catan"


def test_impossible_request_still_answers_and_says_so():
    result = recommend("2 players under 10 minutes")
    assert result["game"] is not None
    assert "10 minutes" in result["reason"]


def test_hard_constraints_are_respected():
    games = load_games().set_index("name")
    game = recommend("a game for 6 people")["game"]
    assert games.loc[game, "min_players"] <= 6 <= games.loc[game, "max_players"]


def test_dataset_validation_catches_bad_rows():
    df = load_games()
    df.loc[0, "min_players"] = 10
    with pytest.raises(ValueError):
        validate(df)


# --- API ---

client = TestClient(app)


def test_api_recommend():
    r = client.post("/recommend", json={"query": "game for my partner"})
    assert r.status_code == 200
    assert set(r.json()) == {"game", "reason"}


def test_api_rejects_empty_query():
    assert client.post("/recommend", json={"query": ""}).status_code == 422


def test_health():
    assert client.get("/health").json()["games_loaded"] == 10



@pytest.mark.parametrize("text, expected", [
    ("เกมสำหรับ 4 คน", "Thai"),
    ("子供と遊べるゲーム", "Japanese"),
    ("适合两个人玩的游戏", "Chinese"),
    ("두 명이 할 게임", "Korean"),
])
def test_reply_language_from_script(text, expected):
    assert reply_language(text, Intent(), "fallback") == expected


def test_reply_language_latin_uses_parser_guess():
    assert reply_language("Busco un juego", Intent(language="Spanish"), "llm") == "Spanish"
    assert reply_language("Busco un juego", Intent(language="Spanish"), "fallback") == "English"
